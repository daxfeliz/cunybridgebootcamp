from get_pokemon_color_palletes import get_pkmn_pallete
import numpy as np
import matplotlib.pyplot as plt


pkmn=str(413)

pkmn='pikachu'

pkmn='Skeledirge'

colors = get_pkmn_pallete(pkmn)

for x in range(len(colors)):

    plt.scatter(x,np.sin(x),color=np.array(colors[x]),s=20**2)
    
plt.gca().set_facecolor('black')

plt.xticks([])

plt.yticks([])

plt.savefig('pkmn_pallete.png')

plt.close()
